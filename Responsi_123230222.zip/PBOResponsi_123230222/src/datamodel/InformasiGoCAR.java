/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datamodel;

/**
 *
 * @author Lab Informatika
 */
public class InformasiGoCAR {
    private int id;
    String namaPenyewa;
    
    public InformasiGoCAR(int id, String nama){
        this.id = id;
        this.namaPenyewa = nama;
    }
    
    public int  getId() {
        return id;
    }
    
    public void  setId(int id) {
        this.id = id;
    }
    public String  getNama() {
        return namaPenyewa;
    }
    
    public void  setNama(String nama) {
        this.namaPenyewa = nama;
    }
}
