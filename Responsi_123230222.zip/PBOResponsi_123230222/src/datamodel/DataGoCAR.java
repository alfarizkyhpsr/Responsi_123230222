/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datamodel;

import javax.print.DocFlavor;

/**
 *
 * @author Lab Informatika
 */
public class DataGoCAR  extends InformasiGoCAR {
    private  int kontak;
    private String jenis_mobil;
    private int durasi;
    private String status_pembayaran;
   
    public DataGoCAR(int id, int kontak, String jenis_mobil, int durasi, String status_pembayaran){
       super(id, namaPenyewa);
       
       this.kontak = kontak;
       this.jenis_mobil = jenis_mobil;
       this.durasi = durasi;
       this.status_pembayaran = status_pembayaran;
    }
    
    public DataGoCAR(String namaPenyewa, int kontak, String jenis_mobil, int durasi, String status_pembayaran){
     this(0, kontak, jenis_mobil, durasi, status_pembayaran);
    }
    
    public int getKontak(){
      return kontak;
    }
    
    public void setKontak(){
     this.kontak = kontak;
    }
    
    public String getJenisMobil(){
      return jenis_mobil;
    }
    
    public void setJenisMobil(){
     this.jenis_mobil = jenis_mobil;
    }
    
    public int getDurasi(){
      return durasi;
    }
    
    public void setDurasi(){
     this.durasi = durasi;
    }
    
    public String getStatusPembayaran(){
      return status_pembayaran;
    }
    
    public void setStatusPembayaran(){
     this.status_pembayaran = status_pembayaran;
    }
    
    public int getTotalPembayaran(){
     return( durasi) * 300000;
    }
}