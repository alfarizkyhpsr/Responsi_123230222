/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datamodel;

/**
 *
 * @author Lab Informatika
 */

import java.security.URIParameter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KoneksiDatabase {
    private static final String URL =
     "jdbc:mysql://localhost/rental_db";
    private static final  String USER ="root";
    private static final  String PASSWORD ="";
    
    public static Connection connect() {
        try{
        return DriverManager.getConnection(URL, USER,PASSWORD);
    } catch (SQLException e){
      e.printStackTrace();
      return null;
  }  
 }
}