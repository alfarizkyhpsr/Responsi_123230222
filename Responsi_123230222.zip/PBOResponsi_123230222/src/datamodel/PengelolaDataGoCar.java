/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datamodel;

/**
 *
 * @author Lab Informatika
 */


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PengelolaDataGoCar implements InterfaceCRUD<DataGoCAR> {
   private Connection conn;

    public PengelolaDataGoCar() {
        conn = KoneksiDatabase.connect();
    }
   
   public void create (DataGoCAR rental){
    String sql = "INSERT INTO rental (nama, kontak, jenis_mobil, durasi, total_biaya, status_pembayaran) VALUES (?,?,?,?,?,?)";
       try (
           PreparedStatement stmt = conn.prepareStatement(sql)){
            stmt.setString(1, rental.getNama());
            stmt.setInt(2, rental.getKontak());
            stmt.setString(3, rental.getJenisMobil());
            stmt.setInt(4, rental.getDurasi());
            stmt.setInt(5, rental.getTotalPembayaran());
            stmt.setString(6, rental.getStatusPembayaran());
            stmt.executeUpdate();
            ;
      } catch (SQLException e) {
          e.printStackTrace();
       }
   }
   
    public List<DataGoCAR> readAll() {
        List<DataGoCAR> list = new ArrayList<>();
        String sql = "SELECTED * FROM rental";
        try ( Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)){ while(rs.next()){
                DataGoCAR m = new DataGoCAR(
                rs.getInt("id"),
                rs.getString("nama"),
                rs.getInt("kontak"),
                rs.getString("jenis_mobil"),
                rs.getInt("durasi"),
                rs.getInt("total_biaya"),
                rs.getString("status_pembayaran"),
                );
                  list add(m);
                } 
        } catch (SQLException e){
            e.printStackTrace()}
  
    } return list;
}